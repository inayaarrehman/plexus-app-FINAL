# Plexus new library: pending review queue

Generated 2026-10-08T21:39:51.197Z. Staging only; the library is not active and the live app is unchanged.

| Category | Open |
|---|---|
| Medical / source holds | 14 |
| Duplicate decisions (new library) | 32 |
| Timed-library overlaps | 42 to decide, 12 recorded |
| Board ambiguity reviews | 11 |
| Blocked boards | 0 |
| Difficulty calibration warnings | 2 |

## 1. Medical / source holds
### PLX-BCH-009 · Agents using retrograde axonal transport (Biochemistry/Genetics, AI_REVIEWED_REVISED)
Tiles: Tetanus toxin · Herpes simplex virus · Poliovirus · Rabies virus

Issue: The corrected tile (Tetanus toxin, replacing Clostridium tetani) is supported only by the outside citation in Notes (Yen and Thwaites, Lancet 2019). The row still cites Bootcamp Cell Biology > Cytoskeleton p. 8, and Notes say that source names the organism. Confirm the correction and add the supporting reference to the Source field, or record that the mismatch is accepted.

### DERM-034 · Glomus tumor clues (Dermatology, AI_REVIEWED_REVISED)
Tiles: Painful subungual lesion · Red-blue nodule · Glomus body origin · Cold hypersensitivity

Issue: Tile 4 was changed by the review from the source's "Thermoregulatory smooth muscle" to "Cold hypersensitivity", a new clinical feature supported by outside references in Notes (Lee et al, J Hand Surg Eur Vol 2009; Chen et al, JAMA Otolaryngol 2017). The row still cites Bootcamp Vascular Tumors > Glomus Tumor p. 110 only. Confirm the new tile and add the supporting reference to Source, or record that this is accepted (same question as PLX-BCH-009).

### GI-011 · Physiologic inhibitors of gastric acid secretion (GI, AI_REVIEWED_REVISED)
Tiles: Somatostatin · Secretin · Cholecystokinin · Prostaglandin E2

Issue: The review replaced the source tile "GIP" with "Cholecystokinin" (GIP inhibits acid only at supraphysiologic doses). Support for the new tile comes from outside references in Notes (Schubert & Rehfeld, Compr Physiol 2019; Chung et al, Gastroenterology 1994), not from the cited Bootcamp pages (pp. 36, 38-39). Confirm the new tile and add the supporting reference to Source, or record that this is accepted.

### GI-012 · Intestinal hormones that slow gastric emptying (GI, AI_REVIEWED_REVISED)
Tiles: Secretin · Cholecystokinin · Peptide YY · GLP-1

Issue: The review replaced the source tile "GIP" with "Peptide YY" (controlled human studies show GIP does not slow gastric emptying). Support for the new tile comes from outside references in Notes (Meier et al 2004; Goyal et al 2019), not from the cited Bootcamp page (p. 38). Confirm the new tile and add the supporting reference to Source, or record that this is accepted.

### GI-050 · Malabsorption disorders causing enteric hyperoxaluria (calcium oxalate stones) (GI, AI_REVIEWED_REVISED)
Tiles: Celiac disease · Chronic pancreatitis · Small intestinal bacterial overgrowth · Crohn disease

Issue: The review replaced the source tile "Whipple disease" with "Chronic pancreatitis". The Source Section now also lists Pancreas / Chronic Pancreatitis p. 127, but the oxalate-stone link is supported by outside references in Notes (Coe et al, NEJM 1992; Ermer et al 2023). Notes also rate the SIBO tile as only "moderately supported". Confirm the new tile (and SIBO) and add the supporting reference to Source, or record that this is accepted.

### PLX-HEM-015 · Iron-deficiency iron-study pattern (Heme/Onc, AI_REVIEWED_REVISED)
Tiles: Low serum iron · Low ferritin · High TIBC · Low transferrin saturation

Issue: The review replaced the source tile "High transferrin" (a near-duplicate of "High TIBC") with "Low transferrin saturation". The new tile is supported by outside references in Notes (Auerbach & DeLoughery, JAMA 2025; Rohr et al 2023), not by the cited Bootcamp page (p. 18). Low risk (TSAT is serum iron / TIBC), but confirm the new tile and add the reference to Source, or record that this is accepted (same question as DERM-034).

### PLX-HEM-031 · Platelet dense-granule contents (Heme/Onc, AI_REVIEWED_REVISED)
Tiles: ADP · Calcium · Serotonin · ATP

Issue: The review replaced the source tile "Histamine" with "ATP", stating histamine is not a canonical platelet dense-granule constituent. This contradicts the cited Bootcamp page (p. 47) and is supported only by outside references in Notes (Holinstat 2017; Yao & Kahr 2025). Confirm the correction and add the reference to Source, or record that this is accepted (same question as PLX-BCH-009).

### IMM-012 · Sites containing secretory IgA (Immunology, AI_REVIEWED_REVISED)
Tiles: Breast milk · Saliva · Tears · Mucosa-associated lymphoid tissue

Issue: The review replaced the source tile "Sweat" with "Tears". Notes state the Bootcamp source (p. 37) supports only breast milk, saliva and MALT, and that "Tears" rests on the added outside references (Woof & Mestecky, Immunol Rev 2005; Li et al 2019). Confirm the new tile and add the reference to Source, or record that this is accepted (same question as the other source-replacement holds).

### MICRO-011 · Implanted sites classically infected by S. epidermidis (Microbiology, AI_REVIEWED_REVISED)
Tiles: Prosthetic heart valve · Central venous catheter · Ventriculoperitoneal shunt · Prosthetic joint

Issue: The review replaced the source tile "Cardiac implanted device" (overlapping "Prosthetic heart valve") with "Prosthetic joint". The new tile is supported by outside references in Notes (Patel, NEJM 2023; Boyle et al 2018), not by the cited Bootcamp page (p. 26). Confirm the new tile and add the reference to Source, or record that this is accepted (same question as the other source-replacement holds).

### MICRO-064 · Antivirals active against CMV (Microbiology, AI_REVIEWED_REVISED)
Tiles: Ganciclovir · Maribavir · Foscarnet · Cidofovir

Issue: The review replaced the source tile "Valganciclovir" (a prodrug of ganciclovir, so not a distinct tile) with "Maribavir". The new tile is supported by outside references in Notes (FDA Livtencity label 2025; Imlay & Kaul 2021), not by the cited Bootcamp pages (pp. 245, 308). Confirm the new tile and add the reference to Source, or record that this is accepted (same question as the other source-replacement holds).

### MSK-031 · Pediatric hip disorders that can present with referred knee pain (MSK, AI_REVIEWED_REVISED)
Tiles: Slipped capital femoral epiphysis · Legg-Calve-Perthes disease · Transient synovitis of the hip · Hip dislocation

Issue: The review replaced the source tile "Developmental hip dysplasia" with "Transient synovitis of the hip". The new tile is supported by outside references in Notes (de Borja et al 2022; AAP DDH report), not by the cited Bootcamp pages (pp. 157, 185-187). The review also notes that hip dislocation fits only the general referred-pain principle and is "less distinctive". Confirm the new tile and add the reference to Source, or record that this is accepted (same question as the other source-replacement holds).

### NEPH-022 · Uremic complications (Renal, AI_REVIEWED_REVISED)
Tiles: Pericarditis · Encephalopathy · Peripheral neuropathy · Platelet dysfunction

Issue: The review replaced the source tile "Asterixis" (a sign of encephalopathy, so overlapping that tile) with "Peripheral neuropathy". The new tile is supported by outside references in Notes (Vanholder et al 2016; Rehman et al 2017), not by the cited Bootcamp pages (pp. 54, 87, 96). Confirm the new tile and add the reference to Source, or record that this is accepted (same question as the other source-replacement holds).

### NEPH-029 · Neuromuscular causes of respiratory acidosis (Renal, AI_REVIEWED_REVISED)
Tiles: Myasthenia gravis · Amyotrophic lateral sclerosis · Guillain-Barre syndrome · Botulism

Issue: The review replaced the source tile "Multiple sclerosis" with "Botulism" and refined the title. The new tile is supported by outside references in Notes (Wijdicks, Ann Neurol 2017; Mehta 2006), not by the cited Bootcamp pages (pp. 44, 46). Confirm the new tile and add the reference to Source, or record that this is accepted (same question as the other source-replacement holds).

### PULM-015 · Clues to alpha-1 antitrypsin deficiency (Pulmonary, AI_REVIEWED_REVISED)
Tiles: Panacinar emphysema · Decreased serum alpha-1 antitrypsin level · PAS-positive hepatocyte globules · Liver cirrhosis

Issue: The review replaced the source tile "Lower-lobe emphysema" (near-redundant with panacinar emphysema) with "Decreased serum alpha-1 antitrypsin level". Notes state the original source supports only the emphysema, globule and cirrhosis claims, not the serum-level tile, which rests on outside references (Strnad et al, NEJM 2020; ATS/ERS 2003). Confirm the new tile and add the reference to Source, or record that this is accepted (same question as the other source-replacement holds).

## 2. Duplicate decisions (new library)
### Vitamin K-dependent clotting factors  /  Vitamin K-dependent procoagulant factors
treated as the same relationship (set aside); confirm. Shared relationship: both are "vitamin k dependent clotting factor"; 4 of 4 tiles identical; tile wording 100% the same.

| | PLX-BCH-002 (new, Biochemistry/Genetics) | PLX-HEM-002 (new, Heme/Onc) |
|---|---|---|
| Title | Vitamin K-dependent clotting factors | Vitamin K-dependent procoagulant factors |
| Tile 1 | Factor II | Factor II |
| Tile 2 | Factor VII | Factor VII |
| Tile 3 | Factor IX | Factor IX |
| Tile 4 | Factor X | Factor X |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Decide: decisions.json → pairs → "PLX-BCH-002 | PLX-HEM-002": "same" or "distinct"

### Amino acids lost in cystinuria  /  Amino acids lost in cystinuria
treated as the same relationship (set aside); confirm. Shared relationship: both are "amino acid lost cystinuria"; 4 of 4 tiles identical; tile wording 100% the same.

| | PLX-BCH-003 (new, Biochemistry/Genetics) | NEPH-006 (new, Renal) |
|---|---|---|
| Title | Amino acids lost in cystinuria | Amino acids lost in cystinuria |
| Tile 1 | Cystine | Cystine |
| Tile 2 | Ornithine | Ornithine |
| Tile 3 | Lysine | Lysine |
| Tile 4 | Arginine | Arginine |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Decide: decisions.json → pairs → "NEPH-006 | PLX-BCH-003": "same" or "distinct"

### Fat-soluble vitamins  /  Fat-soluble vitamins at risk in pancreatic fat malabsorption
treated as the same relationship (set aside); confirm. Shared relationship: "fat soluble vitamin" vs "fat soluble vitamin risk pancreatic fat malabsorption"; 4 of 4 tiles identical; tile wording 100% the same.

| | PLX-BCH-008 (new, Biochemistry/Genetics) | GI-043 (new, GI) |
|---|---|---|
| Title | Fat-soluble vitamins | Fat-soluble vitamins at risk in pancreatic fat malabsorption |
| Tile 1 | Vitamin A | Vitamin A |
| Tile 2 | Vitamin D | Vitamin D |
| Tile 3 | Vitamin E | Vitamin E |
| Tile 4 | Vitamin K | Vitamin K |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Decide: decisions.json → pairs → "GI-043 | PLX-BCH-008": "same" or "distinct"

### Drugs that disrupt microtubule function  /  Drugs disrupting microtubule dynamics
possible duplicate (held). Shared relationship: both are "drug disrupt microtubule function"; 2 of 4 tiles identical.

| | PLX-BCH-010 (new, Biochemistry/Genetics) | PLEXUS-GEN-003 (new, Genetics) |
|---|---|---|
| Title | Drugs that disrupt microtubule function | Drugs disrupting microtubule dynamics |
| Tile 1 | Mebendazole | Colchicine |
| Tile 2 | Griseofulvin | Vincristine |
| Tile 3 | Colchicine | Vinblastine |
| Tile 4 | Vincristine | Paclitaxel |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: PLEXUS-GEN-003.
Decide: decisions.json → pairs → "PLEXUS-GEN-003 | PLX-BCH-010": "same" or "distinct"

### Classic Marfan syndrome associations  /  Marfan syndrome associations
possible duplicate (held). Shared relationship: both are "findings / associations of marfan syndrome".

| | PLX-BCH-031 (new, Biochemistry/Genetics) | CARD-017 (new, Cardiology) |
|---|---|---|
| Title | Classic Marfan syndrome associations | Marfan syndrome associations |
| Tile 1 | Arachnodactyly | Fibrillin-1 defect |
| Tile 2 | Upward lens subluxation | Upward lens displacement |
| Tile 3 | Aortic dissection | Aortic root enlargement |
| Tile 4 | Pectus deformity | Mitral valve prolapse |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: CARD-017.
Decide: decisions.json → pairs → "CARD-017 | PLX-BCH-031": "same" or "distinct"

### Diagnostic clues for cystinuria  /  Cystine stone clues
possible duplicate (held). Shared relationship: "findings / associations of cystinuria" vs "findings / associations of cystine stone"; 1 of 4 tiles identical.

| | PLX-BCH-052 (new, Biochemistry/Genetics) | NEPH-015 (new, Renal) |
|---|---|---|
| Title | Diagnostic clues for cystinuria | Cystine stone clues |
| Tile 1 | Hexagonal urinary crystals | Hexagonal crystals |
| Tile 2 | Recurrent nephrolithiasis | Positive cyanide-nitroprusside test |
| Tile 3 | Increased urinary cystine | COLA transport defect |
| Tile 4 | Positive cyanide-nitroprusside test | Weak radiopacity on plain radiograph |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: NEPH-015.
Decide: decisions.json → pairs → "NEPH-015 | PLX-BCH-052": "same" or "distinct"

### Causes associated with sideroblastic anemia  /  Acquired sideroblastic-anemia exposures
possible duplicate (held). Shared relationship: "causes of + findings / associations of sideroblastic anemia" vs "acquired sideroblastic anemia exposure"; 2 of 4 tiles identical.

| | PLX-BCH-053 (new, Biochemistry/Genetics) | PLX-HEM-021 (new, Heme/Onc) |
|---|---|---|
| Title | Causes associated with sideroblastic anemia | Acquired sideroblastic-anemia exposures |
| Tile 1 | Vitamin B6 deficiency | Alcohol |
| Tile 2 | Lead poisoning | Isoniazid |
| Tile 3 | Alcohol exposure | Chloramphenicol |
| Tile 4 | Isoniazid | Linezolid |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: PLX-BCH-053.
Decide: decisions.json → pairs → "PLX-BCH-053 | PLX-HEM-021": "same" or "distinct"

### Source-described sideroblastic anemia findings  /  Sideroblastic-anemia diagnostic clues
possible duplicate (held). Shared relationship: both are "findings / associations of sideroblastic anemia"; 1 of 4 tiles identical.

| | PLX-BCH-054 (new, Biochemistry/Genetics) | PLX-HEM-022 (new, Heme/Onc) |
|---|---|---|
| Title | Source-described sideroblastic anemia findings | Sideroblastic-anemia diagnostic clues |
| Tile 1 | Ringed sideroblasts | Ring sideroblasts |
| Tile 2 | Basophilic stippling | Increased serum iron |
| Tile 3 | Microcytosis | Increased ferritin |
| Tile 4 | Elevated serum iron | Normal or decreased TIBC |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: PLX-HEM-022.
Decide: decisions.json → pairs → "PLX-BCH-054 | PLX-HEM-022": "same" or "distinct"

### Classic skeletal findings of rickets  /  Skeletal findings of childhood rickets
possible duplicate (held). Shared relationship: both are "findings / associations of skeletal ricket"; 2 of 4 tiles identical.

| | PLX-BCH-059 (new, Biochemistry/Genetics) | MSK-008 (new, MSK) |
|---|---|---|
| Title | Classic skeletal findings of rickets | Skeletal findings of childhood rickets |
| Tile 1 | Bowed long bones | Metaphyseal cupping |
| Tile 2 | Rachitic rosary | Metaphyseal fraying |
| Tile 3 | Craniotabes | Rachitic rosary |
| Tile 4 | Delayed fontanelle closure | Craniotabes |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: MSK-008.
Decide: decisions.json → pairs → "MSK-008 | PLX-BCH-059": "same" or "distinct"

### Vitamin B12 deficiency diagnostic associations  /  Vitamin B12-deficiency clues
treated as the same relationship (set aside); confirm. Shared relationship: both are "findings / associations of vitamin b12 deficiency"; 3 of 4 tiles identical; tile wording 64% the same.

| | PLX-BCH-063 (new, Biochemistry/Genetics) | PLX-HEM-026 (new, Heme/Onc) |
|---|---|---|
| Title | Vitamin B12 deficiency diagnostic associations | Vitamin B12-deficiency clues |
| Tile 1 | Megaloblastic anemia | Increased methylmalonic acid |
| Tile 2 | Elevated homocysteine | Increased homocysteine |
| Tile 3 | Elevated methylmalonic acid | Hypersegmented neutrophils |
| Tile 4 | Subacute combined degeneration | Subacute combined degeneration |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Decide: decisions.json → pairs → "PLX-BCH-063 | PLX-HEM-026": "same" or "distinct"

### Beta-1 selective blockers  /  Beta-1-selective (cardioselective) antagonists
treated as the same relationship (set aside); confirm. Shared relationship: both are "beta 1 selective blocker"; 3 of 4 tiles identical; tile wording 60% the same.

| | CARD-004 (new, Cardiology) | PHARM-012 (new, Pharmacology) |
|---|---|---|
| Title | Beta-1 selective blockers | Beta-1-selective (cardioselective) antagonists |
| Tile 1 | Metoprolol | Metoprolol |
| Tile 2 | Nebivolol | Bisoprolol |
| Tile 3 | Esmolol | Esmolol |
| Tile 4 | Atenolol | Atenolol |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Decide: decisions.json → pairs → "CARD-004 | PHARM-012": "same" or "distinct"

### Classic associations of Chagas disease  /  Chronic Chagas disease manifestations
possible duplicate (held). Shared relationship: "findings / associations of chaga disease" vs "findings / associations of chronic chaga disease"; 2 of 4 tiles identical.

| | CARD-016 (new, Cardiology) | MICRO-029 (new, Microbiology) |
|---|---|---|
| Title | Classic associations of Chagas disease | Chronic Chagas disease manifestations |
| Tile 1 | Trypanosoma cruzi | Dilated cardiomyopathy |
| Tile 2 | Reduviid insect vector | Cardiac arrhythmias |
| Tile 3 | Megaesophagus | Megaesophagus |
| Tile 4 | Megacolon | Megacolon |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: MICRO-029.
Decide: decisions.json → pairs → "CARD-016 | MICRO-029": "same" or "distinct"

### Second pharyngeal arch cartilage derivatives  /  Second pharyngeal arch derivatives
possible duplicate (held). Shared relationship: "second pharyngeal arch cartilage derivative" vs "second pharyngeal arch derivative"; 2 of 4 tiles identical.

| | CARD-050 (new, Cardiology) | REPRO-003 (new, Reproductive) |
|---|---|---|
| Title | Second pharyngeal arch cartilage derivatives | Second pharyngeal arch derivatives |
| Tile 1 | Stapes | Stapedius muscle |
| Tile 2 | Styloid process | Stylohyoid muscle |
| Tile 3 | Stylohyoid ligament | Stapes |
| Tile 4 | Lesser horn of hyoid | Lesser horn of hyoid |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: REPRO-003.
Decide: decisions.json → pairs → "CARD-050 | REPRO-003": "same" or "distinct"

### High-risk oncogenic HPV types  /  High-risk oncogenic HPV types
treated as the same relationship (set aside); confirm. Shared relationship: both are "high risk oncogenic hpv type"; 4 of 4 tiles identical; tile wording 100% the same.

| | DERM-008 (new, Dermatology) | MICRO-043 (new, Microbiology) |
|---|---|---|
| Title | High-risk oncogenic HPV types | High-risk oncogenic HPV types |
| Tile 1 | HPV 16 | HPV 16 |
| Tile 2 | HPV 18 | HPV 18 |
| Tile 3 | HPV 31 | HPV 31 |
| Tile 4 | HPV 33 | HPV 33 |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Decide: decisions.json → pairs → "DERM-008 | MICRO-043": "same" or "distinct"

### Mucocutaneous Candida syndromes  /  Local mucocutaneous Candida syndromes
possible duplicate (held). Shared relationship: "mucocutaneous candida syndrome" vs "local mucocutaneous candida syndrome"; 2 of 4 tiles identical.

| | DERM-010 (new, Dermatology) | MICRO-024 (new, Microbiology) |
|---|---|---|
| Title | Mucocutaneous Candida syndromes | Local mucocutaneous Candida syndromes |
| Tile 1 | Oral thrush | Oropharyngeal thrush |
| Tile 2 | Candidal esophagitis | Esophageal candidiasis |
| Tile 3 | Vulvovaginal candidiasis | Vulvovaginal candidiasis |
| Tile 4 | Candidal intertrigo | Candidal intertrigo |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: MICRO-024.
Decide: decisions.json → pairs → "DERM-010 | MICRO-024": "same" or "distinct"

### Rhino-orbital mucormycosis clues  /  Rhino-orbital-cerebral mucormycosis clues
possible duplicate (held). Shared relationship: "findings / associations of rhino orbital mucormycosis" vs "findings / associations of rhino orbital cerebral mucormycosis"; 1 of 4 tiles identical.

| | DERM-014 (new, Dermatology) | MICRO-023 (new, Microbiology) |
|---|---|---|
| Title | Rhino-orbital mucormycosis clues | Rhino-orbital-cerebral mucormycosis clues |
| Tile 1 | Necrotic nasal or palatal eschar | Diabetic ketoacidosis |
| Tile 2 | Broad pauciseptate hyphae | Black palatal eschar |
| Tile 3 | Wide-angle branching | Broad pauciseptate hyphae |
| Tile 4 | Amphotericin B | Right-angle hyphal branching |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: MICRO-023.
Decide: decisions.json → pairs → "DERM-014 | MICRO-023": "same" or "distinct"

### Infectious associations of erythema nodosum  /  Infections causing caseating/necrotizing granulomas
possible duplicate (held). Shared relationship: "findings / associations of infectious erythema nodosum" vs "causes of infection causing caseating necrotizing granuloma"; 3 of 4 tiles identical.

| | DERM-018 (new, Dermatology) | PLX-HEM-042 (new, Heme/Onc) |
|---|---|---|
| Title | Infectious associations of erythema nodosum | Infections causing caseating/necrotizing granulomas |
| Tile 1 | Coccidioidomycosis | Tuberculosis |
| Tile 2 | Histoplasmosis | Histoplasmosis |
| Tile 3 | Tuberculosis | Cryptococcosis |
| Tile 4 | Streptococcal infection | Coccidioidomycosis |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_REVISED |

Held until decided: PLX-HEM-042.
Decide: decisions.json → pairs → "DERM-018 | PLX-HEM-042": "same" or "distinct"

### Wilson disease diagnostic associations  /  Wilson disease neurologic and systemic clues
possible duplicate (held). Shared relationship: both are "findings / associations of wilson disease"; 1 of 4 tiles identical.

| | GI-022 (new, GI) | NEU-048 (new, Neurology) |
|---|---|---|
| Title | Wilson disease diagnostic associations | Wilson disease neurologic and systemic clues |
| Tile 1 | ATP7B mutation | Kayser-Fleischer rings |
| Tile 2 | Low ceruloplasmin | Wing-beating tremor |
| Tile 3 | Increased urinary copper | Hepatic dysfunction |
| Tile 4 | Kayser-Fleischer rings | Neuropsychiatric changes |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: NEU-048.
Decide: decisions.json → pairs → "GI-022 | NEU-048": "same" or "distinct"

### Anticancer drugs targeting topoisomerases  /  Topoisomerase-targeting cytotoxic drugs
treated as the same relationship (set aside); confirm. Shared relationship: "anticancer drug targeting topoisomerase" vs "topoisomerase targeting cytotoxic drug"; 4 of 4 tiles identical; tile wording 100% the same.

| | PLEXUS-GEN-002 (new, Genetics) | PLX-HEM-046 (new, Heme/Onc) |
|---|---|---|
| Title | Anticancer drugs targeting topoisomerases | Topoisomerase-targeting cytotoxic drugs |
| Tile 1 | Irinotecan | Irinotecan |
| Tile 2 | Topotecan | Topotecan |
| Tile 3 | Etoposide | Etoposide |
| Tile 4 | Teniposide | Teniposide |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_REVISED |

Decide: decisions.json → pairs → "PLEXUS-GEN-002 | PLX-HEM-046": "same" or "distinct"

### Orotic aciduria from UMP synthase deficiency  /  Hereditary orotic-aciduria clues
treated as the same relationship (set aside); confirm. Shared relationship: both are "orotic aciduria ump synthase deficiency"; 3 of 4 tiles identical; tile wording 62% the same.

| | PLEXUS-GEN-007 (new, Genetics) | PLX-HEM-029 (new, Heme/Onc) |
|---|---|---|
| Title | Orotic aciduria from UMP synthase deficiency | Hereditary orotic-aciduria clues |
| Tile 1 | Elevated urinary orotic acid | UMP synthase deficiency |
| Tile 2 | Megaloblastic anemia | Increased urinary orotic acid |
| Tile 3 | Failure to thrive | Megaloblastic anemia |
| Tile 4 | Normal ammonia | Normal ammonia |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Decide: decisions.json → pairs → "PLEXUS-GEN-007 | PLX-HEM-029": "same" or "distinct"

### Ataxia-telangiectasia clinical and laboratory clues  /  Ataxia-telangiectasia associations
possible duplicate (held). Shared relationship: both are "findings / associations of ataxia telangiectasia laboratory".

| | PLEXUS-GEN-010 (new, Genetics) | NEU-042 (new, Neurology) |
|---|---|---|
| Title | Ataxia-telangiectasia clinical and laboratory clues | Ataxia-telangiectasia associations |
| Tile 1 | Ataxia | ATM gene mutation |
| Tile 2 | Telangiectasias | Cerebellar ataxia |
| Tile 3 | Recurrent sinopulmonary infections | Oculocutaneous telangiectasias |
| Tile 4 | Elevated AFP | IgA deficiency |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: NEU-042.
Decide: decisions.json → pairs → "NEU-042 | PLEXUS-GEN-010": "same" or "distinct"

### Digestive complications of cystic fibrosis  /  Cross-organ clues to cystic fibrosis
possible duplicate (held). Shared relationship: "findings / associations of digestive cystic fibrosis" vs "findings / associations of cross organ cystic fibrosis"; 1 of 4 tiles identical.

| | PLEXUS-GEN-018 (new, Genetics) | PULM-014 (new, Pulmonary) |
|---|---|---|
| Title | Digestive complications of cystic fibrosis | Cross-organ clues to cystic fibrosis |
| Tile 1 | Pancreatic insufficiency | Meconium ileus |
| Tile 2 | Fat-soluble vitamin deficiency | Pancreatic exocrine insufficiency |
| Tile 3 | Meconium ileus | Elevated sweat chloride |
| Tile 4 | Biliary cirrhosis | Congenital absence of the vas deferens |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: PULM-014.
Decide: decisions.json → pairs → "PLEXUS-GEN-018 | PULM-014": "same" or "distinct"

### Vaso-occlusive complications of sickle cell disease  /  Sickle-cell vaso-occlusive manifestations
possible duplicate (held). Shared relationship: both are "findings / associations of vaso occlusive sickle cell disease"; 2 of 4 tiles identical.

| | PLEXUS-GEN-020 (new, Genetics) | PLX-HEM-012 (new, Heme/Onc) |
|---|---|---|
| Title | Vaso-occlusive complications of sickle cell disease | Sickle-cell vaso-occlusive manifestations |
| Tile 1 | Dactylitis | Dactylitis |
| Tile 2 | Acute chest syndrome | Acute chest syndrome |
| Tile 3 | Avascular necrosis | Ischemic stroke |
| Tile 4 | Stroke | Priapism |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: PLX-HEM-012.
Decide: decisions.json → pairs → "PLEXUS-GEN-020 | PLX-HEM-012": "same" or "distinct"

### PNH diagnostic clues  /  Clues to paroxysmal nocturnal hemoglobinuria
possible duplicate (held). Shared relationship: both are "findings / associations of pnh"; 1 of 4 tiles identical.

| | PLX-HEM-009 (new, Heme/Onc) | IMM-017 (new, Immunology) |
|---|---|---|
| Title | PNH diagnostic clues | Clues to paroxysmal nocturnal hemoglobinuria |
| Tile 1 | Acquired PIGA mutation | Loss of CD55 / CD59 |
| Tile 2 | Loss of CD55 and CD59 | Coombs-negative hemolysis |
| Tile 3 | Complement-mediated hemolysis | Hemoglobinuria |
| Tile 4 | Unusual-site venous thrombosis | Hepatic vein thrombosis |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: IMM-017.
Decide: decisions.json → pairs → "IMM-017 | PLX-HEM-009": "same" or "distinct"

### Typical laboratory pattern of hemolysis  /  Laboratory evidence of immune-mediated hemolysis
possible duplicate (held). Shared relationship: "laboratory pattern hemolysis" vs "laboratory evidence immune mediated hemolysis"; 2 of 4 tiles identical.

| | PLX-HEM-010 (new, Heme/Onc) | IMM-033 (new, Immunology) |
|---|---|---|
| Title | Typical laboratory pattern of hemolysis | Laboratory evidence of immune-mediated hemolysis |
| Tile 1 | Increased LDH | Positive direct antiglobulin test |
| Tile 2 | Increased indirect bilirubin | Increased LDH |
| Tile 3 | Decreased haptoglobin | Increased bilirubin |
| Tile 4 | Reticulocytosis | Decreased haptoglobin |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_REVISED |

Held until decided: IMM-033.
Decide: decisions.json → pairs → "IMM-033 | PLX-HEM-010": "same" or "distinct"

### Antiphospholipid-syndrome associations  /  Antiphospholipid syndrome clues
possible duplicate (held). Shared relationship: both are "findings / associations of antiphospholipid syndrome".

| | PLX-HEM-038 (new, Heme/Onc) | MSK-014 (new, MSK) |
|---|---|---|
| Title | Antiphospholipid-syndrome associations | Antiphospholipid syndrome clues |
| Tile 1 | Lupus anticoagulant | Recurrent pregnancy loss |
| Tile 2 | Anticardiolipin antibodies | Venous thrombosis |
| Tile 3 | Anti-beta2-glycoprotein I antibodies | Arterial thrombosis |
| Tile 4 | False-positive nontreponemal syphilis test | Livedo reticularis |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: MSK-014.
Decide: decisions.json → pairs → "MSK-014 | PLX-HEM-038": "same" or "distinct"

### Anti-TNF biologics  /  Antibody-based TNF-alpha inhibitors
possible duplicate (held). Shared relationship: "anti tnf biologic" vs "antibody based tnf alpha inhibitor"; 3 of 4 tiles identical; tile wording 80% the same.

| | IMM-040 (new, Immunology) | MSK-039 (new, MSK) |
|---|---|---|
| Title | Anti-TNF biologics | Antibody-based TNF-alpha inhibitors |
| Tile 1 | Infliximab | Adalimumab |
| Tile 2 | Adalimumab | Infliximab |
| Tile 3 | Golimumab | Golimumab |
| Tile 4 | Certolizumab | Certolizumab pegol |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: MSK-039.
Decide: decisions.json → pairs → "IMM-040 | MSK-039": "same" or "distinct"

### Characteristic muscular findings of tetanus  /  Classic tetanus manifestations
possible duplicate (held). Shared relationship: "findings / associations of muscular tetanus" vs "findings / associations of tetanus"; 2 of 4 tiles identical.

| | MICRO-012 (new, Microbiology) | NEU-010 (new, Neurology) |
|---|---|---|
| Title | Characteristic muscular findings of tetanus | Classic tetanus manifestations |
| Tile 1 | Trismus | Trismus |
| Tile 2 | Risus sardonicus | Risus sardonicus |
| Tile 3 | Opisthotonos | Opisthotonus |
| Tile 4 | Painful muscle spasms | Generalized spastic muscle spasms |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: NEU-010.
Decide: decisions.json → pairs → "MICRO-012 | NEU-010": "same" or "distinct"

### Neuromuscular causes of respiratory acidosis  /  Neuromuscular causes of extrapulmonary restriction
possible duplicate (held). Shared relationship: "causes of neuromuscular respiratory acidosis" vs "causes of neuromuscular extrapulmonary restriction"; 3 of 4 tiles identical; tile wording 80% the same.

| | NEPH-029 (new, Renal) | PULM-006 (new, Pulmonary) |
|---|---|---|
| Title | Neuromuscular causes of respiratory acidosis | Neuromuscular causes of extrapulmonary restriction |
| Tile 1 | Myasthenia gravis | Poliomyelitis |
| Tile 2 | Amyotrophic lateral sclerosis | Amyotrophic lateral sclerosis |
| Tile 3 | Guillain-Barre syndrome | Myasthenia gravis |
| Tile 4 | Botulism | Guillain-Barre syndrome |
| Status | AI_REVIEWED_REVISED | AI_REVIEWED_PASS |

Held until decided: NEPH-029.
Decide: decisions.json → pairs → "NEPH-029 | PULM-006": "same" or "distinct"

### Cranial nerves with medially located somatic motor nuclei  /  Structures passing through the superior orbital fissure
possible duplicate (held). Shared relationship: "cranial nerve medially located somatic motor nuclei" vs "structure passing through superior orbital fissure"; 3 of 4 tiles identical.

| | NEU-005 (new, Neurology) | NEU-019 (new, Neurology) |
|---|---|---|
| Title | Cranial nerves with medially located somatic motor nuclei | Structures passing through the superior orbital fissure |
| Tile 1 | Oculomotor nerve | Oculomotor nerve |
| Tile 2 | Trochlear nerve | Trochlear nerve |
| Tile 3 | Abducens nerve | Abducens nerve |
| Tile 4 | Hypoglossal nerve | Ophthalmic division of trigeminal nerve (V1) |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: NEU-019.
Decide: decisions.json → pairs → "NEU-005 | NEU-019": "same" or "distinct"

### Kallmann syndrome associations  /  Kallmann syndrome clues
possible duplicate (held). Shared relationship: both are "findings / associations of kallmann syndrome"; 1 of 4 tiles identical.

| | NEU-046 (new, Neurology) | REPRO-006 (new, Reproductive) |
|---|---|---|
| Title | Kallmann syndrome associations | Kallmann syndrome clues |
| Tile 1 | Anosmia | Anosmia |
| Tile 2 | Impaired GnRH neuron migration | Low GnRH |
| Tile 3 | Low gonadotropins (LH/FSH) | Low gonadotropins |
| Tile 4 | Delayed or absent puberty | Delayed sexual maturation |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: REPRO-006.
Decide: decisions.json → pairs → "NEU-046 | REPRO-006": "same" or "distinct"

### Symptomatic Alzheimer disease pharmacotherapy  /  Acetylcholinesterase inhibitors with CNS penetration
possible duplicate (held). Shared relationship: "symptomatic alzheimer disease pharmacotherapy" vs "acetylcholinesterase inhibitor cns penetration"; 3 of 4 tiles identical; tile wording 60% the same.

| | NEU-051 (new, Neurology) | PHARM-007 (new, Pharmacology) |
|---|---|---|
| Title | Symptomatic Alzheimer disease pharmacotherapy | Acetylcholinesterase inhibitors with CNS penetration |
| Tile 1 | Donepezil | Donepezil |
| Tile 2 | Rivastigmine | Rivastigmine |
| Tile 3 | Galantamine | Galantamine |
| Tile 4 | Memantine | Physostigmine |
| Status | AI_REVIEWED_PASS | AI_REVIEWED_PASS |

Held until decided: PHARM-007.
Decide: decisions.json → pairs → "NEU-051 | PHARM-007": "same" or "distinct"

## 3. Timed-library overlaps
### Fat-soluble vitamins  /  Fat-soluble vitamins
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: both are "fat soluble vitamin"; 4 of 4 tiles identical; tile wording 100% the same.

| | PLX-BCH-008 (new, Biochemistry/Genetics) | bank-ext-001 (timed, Biochemistry/Genetics) |
|---|---|---|
| Title | Fat-soluble vitamins | Fat-soluble vitamins |
| Tile 1 | Vitamin A | Vitamin A |
| Tile 2 | Vitamin D | Vitamin D |
| Tile 3 | Vitamin E | Vitamin E |
| Tile 4 | Vitamin K | Vitamin K |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Storage diseases with enzyme replacement described in the source  /  Lysosomal storage diseases
possible repeat of a timed entry. Shared relationship: "storage disease enzyme replacement" vs "lysosomal storage disease"; 3 of 4 tiles identical; tile wording 63% the same.

| | PLX-BCH-079 (new, Biochemistry/Genetics) | bank-ext-086 (timed, Biochemistry/Genetics) |
|---|---|---|
| Title | Storage diseases with enzyme replacement described in the source | Lysosomal storage diseases |
| Tile 1 | Fabry disease | Tay-Sachs disease |
| Tile 2 | Gaucher disease | Gaucher disease |
| Tile 3 | Hurler syndrome | Fabry disease |
| Tile 4 | Pompe disease | Hurler syndrome |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PLX-BCH-079 | bank-ext-086": "same" (exclude timed entry at activation) or "distinct"

### The four defects in tetralogy of Fallot  /  Findings in tetralogy of Fallot
possible repeat of a timed entry. Shared relationship: both are "defect tetralogy fallot"; 2 of 4 tiles identical; tile wording 82% the same.

| | CARD-001 (new, Cardiology) | bank-ext-050 (timed, Cardiology) |
|---|---|---|
| Title | The four defects in tetralogy of Fallot | Findings in tetralogy of Fallot |
| Tile 1 | Pulmonary outflow stenosis | Pulmonary stenosis |
| Tile 2 | Aorta overriding the septum | Right ventricular hypertrophy |
| Tile 3 | Ventricular septal defect | Overriding aorta |
| Tile 4 | Right ventricular hypertrophy | Ventricular septal defect |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "CARD-001 | bank-ext-050": "same" (exclude timed entry at activation) or "distinct"

### Classic causes of high-output heart failure  /  Causes of high-output heart failure
possible repeat of a timed entry. Shared relationship: both are "causes of high output heart failure"; 2 of 4 tiles identical; tile wording 67% the same.

| | CARD-002 (new, Cardiology) | bank-medium-16 (timed, Cardiology) |
|---|---|---|
| Title | Classic causes of high-output heart failure | Causes of high-output heart failure |
| Tile 1 | Thiamine deficiency | Severe anemia |
| Tile 2 | Severe anemia | Thyrotoxicosis |
| Tile 3 | Hyperthyroidism | Arteriovenous fistula |
| Tile 4 | Arteriovenous fistula | Thiamine deficiency (beriberi) |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "CARD-002 | bank-medium-16": "same" (exclude timed entry at activation) or "distinct"

### Classic causes of high-output heart failure  /  Causes of a widened pulse pressure
possible repeat of a timed entry. Shared relationship: "causes of high output heart failure" vs "causes of widened pulse pressure"; 3 of 4 tiles identical.

| | CARD-002 (new, Cardiology) | bank-migrated-sys-cardio-0002-L4 (timed, Cardiology) |
|---|---|---|
| Title | Classic causes of high-output heart failure | Causes of a widened pulse pressure |
| Tile 1 | Thiamine deficiency | Aortic regurgitation |
| Tile 2 | Severe anemia | Hyperthyroidism |
| Tile 3 | Hyperthyroidism | Severe anemia |
| Tile 4 | Arteriovenous fistula | Arteriovenous fistula |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "CARD-002 | bank-migrated-sys-cardio-0002-L4": "same" (exclude timed entry at activation) or "distinct"

### Drugs that slow AV nodal conduction  /  Drugs that slow AV nodal conduction
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: both are "drug slow av nodal conduction"; 3 of 4 tiles identical; tile wording 60% the same.

| | CARD-007 (new, Cardiology) | bank-ext-020 (timed, Pharmacology) |
|---|---|---|
| Title | Drugs that slow AV nodal conduction | Drugs that slow AV nodal conduction |
| Tile 1 | Verapamil | Adenosine |
| Tile 2 | Diltiazem | Diltiazem |
| Tile 3 | Metoprolol | Metoprolol |
| Tile 4 | Digoxin | Digoxin |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Conditions that can produce restrictive cardiomyopathy  /  Causes of restrictive cardiomyopathy
possible repeat of a timed entry. Shared relationship: both are "causes of restrictive cardiomyopathy"; 1 of 4 tiles identical.

| | CARD-012 (new, Cardiology) | bank-ext-051 (timed, Cardiology) |
|---|---|---|
| Title | Conditions that can produce restrictive cardiomyopathy | Causes of restrictive cardiomyopathy |
| Tile 1 | Cardiac amyloidosis | Amyloidosis |
| Tile 2 | Hemochromatosis | Hemochromatosis |
| Tile 3 | Cardiac sarcoidosis | Sarcoidosis |
| Tile 4 | Chest irradiation | Endomyocardial fibrosis |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "CARD-012 | bank-ext-051": "same" (exclude timed entry at activation) or "distinct"

### Classic cardiac tamponade findings  /  Findings in cardiac tamponade
possible repeat of a timed entry. Shared relationship: both are "findings / associations of cardiac tamponade"; 1 of 4 tiles identical.

| | CARD-034 (new, Cardiology) | bank-migrated-sys-mixed-0002-L4 (timed, Mixed / Step Review) |
|---|---|---|
| Title | Classic cardiac tamponade findings | Findings in cardiac tamponade |
| Tile 1 | Low blood pressure | Pulsus paradoxus |
| Tile 2 | Distended neck veins | Electrical alternans |
| Tile 3 | Quiet heart sounds | Beck's triad |
| Tile 4 | Pulsus paradoxus | Low-voltage QRS on ECG |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "CARD-034 | bank-migrated-sys-mixed-0002-L4": "same" (exclude timed entry at activation) or "distinct"

### Endocrine causes of secondary hypertension  /  Causes of secondary hypertension
possible repeat of a timed entry. Shared relationship: "causes of endocrine secondary hypertension" vs "causes of secondary hypertension"; 2 of 4 tiles identical.

| | CARD-044 (new, Cardiology) | bank-easy-14 (timed, Endocrine) |
|---|---|---|
| Title | Endocrine causes of secondary hypertension | Causes of secondary hypertension |
| Tile 1 | Cushing syndrome | Renal artery stenosis |
| Tile 2 | Hyperaldosteronism | Pheochromocytoma |
| Tile 3 | Pheochromocytoma | Cushing syndrome |
| Tile 4 | Hyperthyroidism | Primary hyperaldosteronism |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "CARD-044 | bank-easy-14": "same" (exclude timed entry at activation) or "distinct"

### Infectious associations of erythema nodosum  /  Granulomatous infections with necrotizing (caseating) granulomas
possible repeat of a timed entry. Shared relationship: "findings / associations of infectious erythema nodosum" vs "granulomatous infection necrotizing caseating granuloma"; 3 of 4 tiles identical.

| | DERM-018 (new, Dermatology) | bank-easy-04 (timed, Microbiology) |
|---|---|---|
| Title | Infectious associations of erythema nodosum | Granulomatous infections with necrotizing (caseating) granulomas |
| Tile 1 | Coccidioidomycosis | Tuberculosis |
| Tile 2 | Histoplasmosis | Histoplasmosis |
| Tile 3 | Tuberculosis | Coccidioidomycosis |
| Tile 4 | Streptococcal infection | Nontuberculous mycobacterial infection |
| Status | AI_REVIEWED_PASS | needs_review |

Decide: decisions.json → pairs → "DERM-018 | bank-easy-04": "same" (exclude timed entry at activation) or "distinct"

### Psoriasis clinical associations  /  Features of psoriasis
possible repeat of a timed entry. Shared relationship: both are "findings / associations of psoriasis"; 2 of 4 tiles identical.

| | DERM-029 (new, Dermatology) | bank-ext-110 (timed, Dermatology) |
|---|---|---|
| Title | Psoriasis clinical associations | Features of psoriasis |
| Tile 1 | Silvery plaques | Silvery scale |
| Tile 2 | Auspitz sign | Auspitz sign |
| Tile 3 | Nail pitting | Nail pitting |
| Tile 4 | Psoriatic arthritis | Extensor-surface plaques |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "DERM-029 | bank-ext-110": "same" (exclude timed entry at activation) or "distinct"

### Manifestations of hypocalcemic neuromuscular excitability  /  Signs of hypocalcemia
possible repeat of a timed entry. Shared relationship: both are "findings / associations of hypocalcemic neuromuscular excitability"; 2 of 4 tiles identical.

| | ENDO-019 (new, Endocrine) | bank-migrated-sys-mixed-0002-L3 (timed, Mixed / Step Review) |
|---|---|---|
| Title | Manifestations of hypocalcemic neuromuscular excitability | Signs of hypocalcemia |
| Tile 1 | Chvostek sign | Chvostek's sign |
| Tile 2 | Trousseau sign | Trousseau's sign |
| Tile 3 | Tetany | Carpopedal spasm |
| Tile 4 | Seizures | Prolonged QT interval |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "ENDO-019 | bank-migrated-sys-mixed-0002-L3": "same" (exclude timed entry at activation) or "distinct"

### Hereditary syndromes associated with pheochromocytoma  /  Conditions associated with pheochromocytoma
possible repeat of a timed entry. Shared relationship: "findings / associations of hereditary syndrome pheochromocytoma" vs "causes of + findings / associations of pheochromocytoma"; 3 of 4 tiles identical; tile wording 80% the same.

| | ENDO-029 (new, Endocrine) | bank-ext-082 (timed, Endocrine) |
|---|---|---|
| Title | Hereditary syndromes associated with pheochromocytoma | Conditions associated with pheochromocytoma |
| Tile 1 | Neurofibromatosis type 1 | MEN2A |
| Tile 2 | Von Hippel-Lindau syndrome | MEN2B |
| Tile 3 | MEN2A | Von Hippel-Lindau disease |
| Tile 4 | MEN2B | Neurofibromatosis type 1 |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "ENDO-029 | bank-ext-082": "same" (exclude timed entry at activation) or "distinct"

### Manifestations of portal hypertension  /  Consequences of portal hypertension
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: both are "findings / associations of portal hypertension"; 3 of 4 tiles identical; tile wording 71% the same.

| | GI-029 (new, GI) | bank-ext-024 (timed, GI) |
|---|---|---|
| Title | Manifestations of portal hypertension | Consequences of portal hypertension |
| Tile 1 | Esophageal varices | Esophageal varices |
| Tile 2 | Anorectal varices | Caput medusae |
| Tile 3 | Caput medusae | Splenomegaly |
| Tile 4 | Splenomegaly | Ascites |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Hereditary bilirubin-handling disorders  /  Inherited hyperbilirubinemia syndromes
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: both are "hereditary bilirubin handling disorder"; 4 of 4 tiles identical; tile wording 100% the same.

| | GI-033 (new, GI) | bank-ext-114 (timed, GI) |
|---|---|---|
| Title | Hereditary bilirubin-handling disorders | Inherited hyperbilirubinemia syndromes |
| Tile 1 | Gilbert syndrome | Gilbert syndrome |
| Tile 2 | Crigler-Najjar syndrome | Crigler-Najjar syndrome |
| Tile 3 | Dubin-Johnson syndrome | Dubin-Johnson syndrome |
| Tile 4 | Rotor syndrome | Rotor syndrome |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Fat-soluble vitamins at risk in pancreatic fat malabsorption  /  Fat-soluble vitamins
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: "fat soluble vitamin risk pancreatic fat malabsorption" vs "fat soluble vitamin"; 4 of 4 tiles identical; tile wording 100% the same.

| | GI-043 (new, GI) | bank-ext-001 (timed, Biochemistry/Genetics) |
|---|---|---|
| Title | Fat-soluble vitamins at risk in pancreatic fat malabsorption | Fat-soluble vitamins |
| Tile 1 | Vitamin A | Vitamin A |
| Tile 2 | Vitamin D | Vitamin D |
| Tile 3 | Vitamin E | Vitamin E |
| Tile 4 | Vitamin K | Vitamin K |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Systemic manifestations of carcinoid syndrome  /  Features of carcinoid syndrome
possible repeat of a timed entry. Shared relationship: both are "findings / associations of systemic carcinoid syndrome"; 1 of 4 tiles identical.

| | GI-056 (new, GI) | bank-ext-023 (timed, GI) |
|---|---|---|
| Title | Systemic manifestations of carcinoid syndrome | Features of carcinoid syndrome |
| Tile 1 | Flushing | Flushing |
| Tile 2 | Watery diarrhea | Diarrhea |
| Tile 3 | Bronchospasm | Wheezing |
| Tile 4 | Right-sided valvular fibrosis | Right-sided valvular disease |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "GI-056 | bank-ext-023": "same" (exclude timed entry at activation) or "distinct"

### Autosomal dominant hereditary colorectal cancer syndromes  /  Hereditary colorectal cancer syndromes
possible repeat of a timed entry. Shared relationship: "autosomal dominant hereditary colorectal cancer syndrome" vs "hereditary colorectal cancer syndrome"; 3 of 4 tiles identical; tile wording 100% the same.

| | GI-062 (new, GI) | bank-ext-115 (timed, GI) |
|---|---|---|
| Title | Autosomal dominant hereditary colorectal cancer syndromes | Hereditary colorectal cancer syndromes |
| Tile 1 | Lynch syndrome | Lynch syndrome |
| Tile 2 | Familial adenomatous polyposis | Familial adenomatous polyposis |
| Tile 3 | Peutz-Jeghers syndrome | Peutz-Jeghers syndrome |
| Tile 4 | Juvenile polyposis syndrome | Juvenile polyposis |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "GI-062 | bank-ext-115": "same" (exclude timed entry at activation) or "distinct"

### Trinucleotide repeat expansion disorders  /  Trinucleotide repeat disorders
possible repeat of a timed entry. Shared relationship: "trinucleotide repeat expansion disorder" vs "trinucleotide repeat disorder"; 2 of 4 tiles identical; tile wording 67% the same.

| | PLEXUS-GEN-004 (new, Genetics) | bank-migrated-sys-biochem-0001-L4 (timed, Biochemistry/Genetics) |
|---|---|---|
| Title | Trinucleotide repeat expansion disorders | Trinucleotide repeat disorders |
| Tile 1 | Fragile X syndrome | Fragile X syndrome |
| Tile 2 | Friedreich ataxia | Myotonic dystrophy |
| Tile 3 | Huntington disease | Friedreich ataxia |
| Tile 4 | Myotonic dystrophy type 1 | Kennedy disease |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PLEXUS-GEN-004 | bank-migrated-sys-biochem-0001-L4": "same" (exclude timed entry at activation) or "distinct"

### Schistocyte-producing red-cell destruction  /  Causes of microangiopathic hemolytic anemia
possible repeat of a timed entry. Shared relationship: "schistocyte producing red cell destruction" vs "causes of microangiopathic hemolytic anemia"; 3 of 4 tiles identical; tile wording 60% the same.

| | PLX-HEM-011 (new, Heme/Onc) | bank-ext-058 (timed, Heme/Onc) |
|---|---|---|
| Title | Schistocyte-producing red-cell destruction | Causes of microangiopathic hemolytic anemia |
| Tile 1 | Thrombotic thrombocytopenic purpura | Thrombotic thrombocytopenic purpura |
| Tile 2 | Hemolytic uremic syndrome | Hemolytic uremic syndrome |
| Tile 3 | Disseminated intravascular coagulation | Disseminated intravascular coagulation |
| Tile 4 | Mechanical prosthetic-valve hemolysis | Malignant hypertension |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PLX-HEM-011 | bank-ext-058": "same" (exclude timed entry at activation) or "distinct"

### Infections causing caseating/necrotizing granulomas  /  Granulomatous infections with necrotizing (caseating) granulomas
possible repeat of a timed entry. Shared relationship: "causes of infection causing caseating necrotizing granuloma" vs "granulomatous infection necrotizing caseating granuloma"; 3 of 4 tiles identical.

| | PLX-HEM-042 (new, Heme/Onc) | bank-easy-04 (timed, Microbiology) |
|---|---|---|
| Title | Infections causing caseating/necrotizing granulomas | Granulomatous infections with necrotizing (caseating) granulomas |
| Tile 1 | Tuberculosis | Tuberculosis |
| Tile 2 | Histoplasmosis | Histoplasmosis |
| Tile 3 | Cryptococcosis | Coccidioidomycosis |
| Tile 4 | Coccidioidomycosis | Nontuberculous mycobacterial infection |
| Status | AI_REVIEWED_REVISED | needs_review |

Decide: decisions.json → pairs → "PLX-HEM-042 | bank-easy-04": "same" (exclude timed entry at activation) or "distinct"

### Live attenuated viral vaccines  /  Live attenuated vaccines
possible repeat of a timed entry. Shared relationship: "live attenuated viral vaccine" vs "live attenuated vaccine"; 3 of 4 tiles identical.

| | IMM-018 (new, Immunology) | bank-ext-002 (timed, Microbiology) |
|---|---|---|
| Title | Live attenuated viral vaccines | Live attenuated vaccines |
| Tile 1 | MMR vaccine | MMR |
| Tile 2 | Varicella vaccine | Varicella |
| Tile 3 | Rotavirus vaccine | Rotavirus |
| Tile 4 | Yellow fever vaccine | Intranasal influenza |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "IMM-018 | bank-ext-002": "same" (exclude timed entry at activation) or "distinct"

### Classic immune-complex hypersensitivity examples  /  Type III hypersensitivity diseases
possible repeat of a timed entry. Shared relationship: "immune complex hypersensitivity example" vs "type iii hypersensitivity disease"; 3 of 4 tiles identical.

| | IMM-030 (new, Immunology) | bank-ext-061 (timed, Immunology) |
|---|---|---|
| Title | Classic immune-complex hypersensitivity examples | Type III hypersensitivity diseases |
| Tile 1 | Serum sickness | Serum sickness |
| Tile 2 | Arthus reaction | Poststreptococcal glomerulonephritis |
| Tile 3 | Poststreptococcal glomerulonephritis | Systemic lupus erythematosus |
| Tile 4 | Immune-complex lupus nephritis | Arthus reaction |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "IMM-030 | bank-ext-061": "same" (exclude timed entry at activation) or "distinct"

### Classic bacterial causes of atypical pneumonia  /  Organisms causing atypical pneumonia
possible repeat of a timed entry. Shared relationship: "causes of bacterial atypical pneumonia" vs "causes of organism causing atypical pneumonia"; 2 of 4 tiles identical.

| | MICRO-009 (new, Microbiology) | bank-ext-032 (timed, Microbiology) |
|---|---|---|
| Title | Classic bacterial causes of atypical pneumonia | Organisms causing atypical pneumonia |
| Tile 1 | Mycoplasma pneumoniae | Mycoplasma pneumoniae |
| Tile 2 | Chlamydia pneumoniae | Legionella pneumophila |
| Tile 3 | Chlamydia psittaci | Chlamydophila pneumoniae |
| Tile 4 | Legionella pneumophila | Coxiella burnetii |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "MICRO-009 | bank-ext-032": "same" (exclude timed entry at activation) or "distinct"

### Pulmonary endemic dimorphic fungi  /  Dimorphic fungi
possible repeat of a timed entry. Shared relationship: "pulmonary endemic dimorphic fungi" vs "dimorphic fungi"; 2 of 4 tiles identical; tile wording 67% the same.

| | MICRO-018 (new, Microbiology) | bank-migrated-sys-micro-0001-L2 (timed, Microbiology) |
|---|---|---|
| Title | Pulmonary endemic dimorphic fungi | Dimorphic fungi |
| Tile 1 | Histoplasma capsulatum | Histoplasma capsulatum |
| Tile 2 | Blastomyces dermatitidis | Coccidioides immitis |
| Tile 3 | Coccidioides species | Blastomyces dermatitidis |
| Tile 4 | Paracoccidioides species | Paracoccidioides brasiliensis |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "MICRO-018 | bank-migrated-sys-micro-0001-L2": "same" (exclude timed entry at activation) or "distinct"

### Rotator cuff muscles  /  Rotator cuff muscles
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: both are "rotator cuff muscle"; 4 of 4 tiles identical; tile wording 100% the same.

| | MSK-001 (new, MSK) | bank-ext-104 (timed, MSK) |
|---|---|---|
| Title | Rotator cuff muscles | Rotator cuff muscles |
| Tile 1 | Supraspinatus | Supraspinatus |
| Tile 2 | Infraspinatus | Infraspinatus |
| Tile 3 | Teres minor | Teres minor |
| Tile 4 | Subscapularis | Subscapularis |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Seronegative spondyloarthritides  /  HLA-B27-associated spondyloarthropathies
possible repeat of a timed entry. Shared relationship: "seronegative spondyloarthritide" vs "findings / associations of hla b27 spondyloarthropathie"; 3 of 4 tiles identical; tile wording 78% the same.

| | MSK-002 (new, MSK) | bank-easy-05 (timed, MSK) |
|---|---|---|
| Title | Seronegative spondyloarthritides | HLA-B27-associated spondyloarthropathies |
| Tile 1 | Ankylosing spondylitis | Ankylosing spondylitis |
| Tile 2 | Psoriatic arthritis | Reactive arthritis |
| Tile 3 | Reactive arthritis | Psoriatic arthritis |
| Tile 4 | IBD-associated (enteropathic) spondyloarthritis | IBD-associated arthritis |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "MSK-002 | bank-easy-05": "same" (exclude timed entry at activation) or "distinct"

### Seronegative spondyloarthritides  /  Seronegative spondyloarthropathies
possible repeat of a timed entry. Shared relationship: "seronegative spondyloarthritide" vs "seronegative spondyloarthropathie"; 3 of 4 tiles identical; tile wording 67% the same.

| | MSK-002 (new, MSK) | bank-ext-103 (timed, MSK) |
|---|---|---|
| Title | Seronegative spondyloarthritides | Seronegative spondyloarthropathies |
| Tile 1 | Ankylosing spondylitis | Ankylosing spondylitis |
| Tile 2 | Psoriatic arthritis | Psoriatic arthritis |
| Tile 3 | Reactive arthritis | Reactive arthritis |
| Tile 4 | IBD-associated (enteropathic) spondyloarthritis | Enteropathic arthritis |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "MSK-002 | bank-ext-103": "same" (exclude timed entry at activation) or "distinct"

### Classic radiographic changes of osteoarthritis  /  Radiographic findings in osteoarthritis
possible repeat of a timed entry. Shared relationship: both are "findings / associations of radiographic osteoarthritis"; 2 of 4 tiles identical.

| | MSK-005 (new, MSK) | bank-ext-105 (timed, MSK) |
|---|---|---|
| Title | Classic radiographic changes of osteoarthritis | Radiographic findings in osteoarthritis |
| Tile 1 | Nonuniform (asymmetric) joint-space loss | Joint space narrowing |
| Tile 2 | Subchondral sclerosis | Osteophytes |
| Tile 3 | Marginal osteophytes | Subchondral sclerosis |
| Tile 4 | Subchondral cysts | Subchondral cysts |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "MSK-005 | bank-ext-105": "same" (exclude timed entry at activation) or "distinct"

### Sarcoidosis diagnostic associations  /  Features of sarcoidosis
possible repeat of a timed entry. Shared relationship: both are "findings / associations of sarcoidosis"; 2 of 4 tiles identical.

| | MSK-018 (new, MSK) | bank-ext-066 (timed, Mixed / Step Review) |
|---|---|---|
| Title | Sarcoidosis diagnostic associations | Features of sarcoidosis |
| Tile 1 | Bilateral hilar lymphadenopathy | Bilateral hilar lymphadenopathy |
| Tile 2 | Noncaseating granulomas | Noncaseating granulomas |
| Tile 3 | Elevated serum ACE | Hypercalcemia |
| Tile 4 | Increased BAL CD4:CD8 ratio | Erythema nodosum |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "MSK-018 | bank-ext-066": "same" (exclude timed entry at activation) or "distinct"

### Classic nephrotic syndrome findings  /  Nephrotic syndrome findings
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: both are "findings / associations of nephrotic syndrome"; 3 of 4 tiles identical; tile wording 67% the same.

| | NEPH-007 (new, Renal) | bank-migrated-sys-renal-0002-L1 (timed, Renal) |
|---|---|---|
| Title | Classic nephrotic syndrome findings | Nephrotic syndrome findings |
| Tile 1 | Heavy proteinuria | Massive proteinuria |
| Tile 2 | Hypoalbuminemia | Hypoalbuminemia |
| Tile 3 | Edema | Edema |
| Tile 4 | Hyperlipidemia | Hyperlipidemia |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Renal papillary necrosis associations  /  Causes of renal papillary necrosis
possible repeat of a timed entry. Shared relationship: "findings / associations of renal papillary necrosis" vs "causes of renal papillary necrosis"; 3 of 4 tiles identical.

| | NEPH-018 (new, Renal) | bank-ext-081 (timed, Renal) |
|---|---|---|
| Title | Renal papillary necrosis associations | Causes of renal papillary necrosis |
| Tile 1 | Sickle cell disease | Sickle cell disease |
| Tile 2 | Acute pyelonephritis | Analgesic nephropathy |
| Tile 3 | Chronic NSAID exposure | Diabetes mellitus |
| Tile 4 | Diabetes mellitus | Acute pyelonephritis |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "NEPH-018 | bank-ext-081": "same" (exclude timed entry at activation) or "distinct"

### Medications that can cause acute interstitial nephritis  /  Drugs causing acute interstitial nephritis
possible repeat of a timed entry. Shared relationship: "causes of medication acute interstitial nephritis" vs "causes of drug causing acute interstitial nephritis"; 3 of 4 tiles identical; tile wording 71% the same.

| | NEPH-019 (new, Renal) | bank-ext-054 (timed, Renal) |
|---|---|---|
| Title | Medications that can cause acute interstitial nephritis | Drugs causing acute interstitial nephritis |
| Tile 1 | NSAIDs | NSAIDs |
| Tile 2 | Penicillins | Penicillins |
| Tile 3 | Proton pump inhibitors | Sulfonamides |
| Tile 4 | Rifampin | Proton pump inhibitors |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "NEPH-019 | bank-ext-054": "same" (exclude timed entry at activation) or "distinct"

### Normal-anion-gap metabolic acidosis associations  /  Causes of non-anion gap metabolic acidosis
possible repeat of a timed entry. Shared relationship: "findings / associations of normal anion gap metabolic acidosis" vs "causes of non anion gap metabolic acidosis"; 2 of 4 tiles identical.

| | NEPH-028 (new, Renal) | bank-migrated-sys-renal-0001-L2 (timed, Renal) |
|---|---|---|
| Title | Normal-anion-gap metabolic acidosis associations | Causes of non-anion gap metabolic acidosis |
| Tile 1 | Diarrhea | Diarrhea |
| Tile 2 | Acetazolamide | Renal tubular acidosis |
| Tile 3 | Distal renal tubular acidosis | Acetazolamide |
| Tile 4 | Proximal renal tubular acidosis | Early renal failure |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "NEPH-028 | bank-migrated-sys-renal-0001-L2": "same" (exclude timed entry at activation) or "distinct"

### Neuromuscular causes of respiratory acidosis  /  Causes of respiratory acidosis
possible repeat of a timed entry. Shared relationship: "causes of neuromuscular respiratory acidosis" vs "causes of respiratory acidosis"; 1 of 4 tiles identical.

| | NEPH-029 (new, Renal) | bank-migrated-sys-renal-0001-L4 (timed, Renal) |
|---|---|---|
| Title | Neuromuscular causes of respiratory acidosis | Causes of respiratory acidosis |
| Tile 1 | Myasthenia gravis | Opioid overdose |
| Tile 2 | Amyotrophic lateral sclerosis | COPD exacerbation |
| Tile 3 | Guillain-Barre syndrome | Guillain-Barré syndrome |
| Tile 4 | Botulism | Obesity hypoventilation syndrome |
| Status | AI_REVIEWED_REVISED | verified |

Decide: decisions.json → pairs → "NEPH-029 | bank-migrated-sys-renal-0001-L4": "same" (exclude timed entry at activation) or "distinct"

### Upper motor neuron examination signs  /  Upper motor neuron signs
possible repeat of a timed entry. Shared relationship: "findings / associations of upper motor neuron examination" vs "findings / associations of upper motor neuron"; 2 of 4 tiles identical.

| | NEU-002 (new, Neurology) | bank-ext-034 (timed, Neurology) |
|---|---|---|
| Title | Upper motor neuron examination signs | Upper motor neuron signs |
| Tile 1 | Hyperreflexia | Hyperreflexia |
| Tile 2 | Spasticity | Spasticity |
| Tile 3 | Hypertonia | Babinski sign |
| Tile 4 | Extensor plantar response | Clonus |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "NEU-002 | bank-ext-034": "same" (exclude timed entry at activation) or "distinct"

### Lower motor neuron examination signs  /  Lower motor neuron signs
possible repeat of a timed entry. Shared relationship: "findings / associations of low motor neuron examination" vs "findings / associations of low motor neuron"; 3 of 4 tiles identical.

| | NEU-003 (new, Neurology) | bank-ext-035 (timed, Neurology) |
|---|---|---|
| Title | Lower motor neuron examination signs | Lower motor neuron signs |
| Tile 1 | Fasciculations | Fasciculations |
| Tile 2 | Muscle atrophy | Hyporeflexia |
| Tile 3 | Hyporeflexia | Muscle atrophy |
| Tile 4 | Hypotonia | Flaccid paralysis |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "NEU-003 | bank-ext-035": "same" (exclude timed entry at activation) or "distinct"

### Classic Parkinson disease motor findings  /  Features of Parkinson disease
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: "findings / associations of parkinson disease motor" vs "findings / associations of parkinson disease"; 4 of 4 tiles identical; tile wording 100% the same.

| | NEU-052 (new, Neurology) | bank-migrated-sys-neuro-0002-L1 (timed, Neurology) |
|---|---|---|
| Title | Classic Parkinson disease motor findings | Features of Parkinson disease |
| Tile 1 | Bradykinesia | Resting tremor |
| Tile 2 | Resting tremor | Bradykinesia |
| Tile 3 | Cogwheel rigidity | Cogwheel rigidity |
| Tile 4 | Postural instability | Postural instability |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Gq-coupled receptors  /  Gq-coupled receptors
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: both are "gq coupled receptor"; 3 of 4 tiles identical; tile wording 71% the same.

| | PHARM-004 (new, Pharmacology) | bank-medium-02 (timed, Pharmacology) |
|---|---|---|
| Title | Gq-coupled receptors | Gq-coupled receptors |
| Tile 1 | M1 receptor | α1 receptor |
| Tile 2 | M3 receptor | H1 receptor |
| Tile 3 | Alpha-1 receptor | V1 receptor |
| Tile 4 | H1 receptor | M1 receptor |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Gs-coupled receptors  /  Gs-coupled receptors (increased cAMP)
possible repeat of a timed entry. Shared relationship: "gs coupled receptor" vs "gs coupled receptor high camp"; 3 of 4 tiles identical; tile wording 71% the same.

| | PHARM-005 (new, Pharmacology) | bank-medium-01 (timed, Pharmacology) |
|---|---|---|
| Title | Gs-coupled receptors | Gs-coupled receptors (increased cAMP) |
| Tile 1 | Beta-1 receptor | β1 receptor |
| Tile 2 | Beta-2 receptor | β2 receptor |
| Tile 3 | D1 receptor | D1 receptor |
| Tile 4 | V2 receptor | H2 receptor |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PHARM-005 | bank-medium-01": "same" (exclude timed entry at activation) or "distinct"

### Peripheral findings of antimuscarinic (anticholinergic) toxicity  /  Muscarinic antagonist effect
possible repeat of a timed entry. Shared relationship: "findings / associations of peripheral antimuscarinic anticholinergic toxicity" vs "muscarinic antagonist effect"; 3 of 4 tiles identical; tile wording 71% the same.

| | PHARM-009 (new, Pharmacology) | bank-migrated-sys-pharm-0002-L3 (timed, Pharmacology) |
|---|---|---|
| Title | Peripheral findings of antimuscarinic (anticholinergic) toxicity | Muscarinic antagonist effect |
| Tile 1 | Mydriasis | Mydriasis |
| Tile 2 | Dry skin | Dry mouth |
| Tile 3 | Urinary retention | Urinary retention |
| Tile 4 | Tachycardia | Tachycardia |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PHARM-009 | bank-migrated-sys-pharm-0002-L3": "same" (exclude timed entry at activation) or "distinct"

### Positive symptoms of schizophrenia  /  Positive symptoms of schizophrenia
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: both are "positive symptom schizophrenia"; 4 of 4 tiles identical; tile wording 100% the same.

| | PSY-006 (new, Psychiatry) | bank-ext-098 (timed, Psychiatry) |
|---|---|---|
| Title | Positive symptoms of schizophrenia | Positive symptoms of schizophrenia |
| Tile 1 | Delusions | Hallucinations |
| Tile 2 | Hallucinations | Delusions |
| Tile 3 | Disorganized speech | Disorganized speech |
| Tile 4 | Disorganized behavior | Disorganized behavior |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### SSRIs inhibiting serotonin reuptake  /  Selective serotonin reuptake inhibitors (SSRIs)
possible repeat of a timed entry. Shared relationship: "ssris inhibiting serotonin reuptake" vs "selective serotonin reuptake inhibitor ssris"; 3 of 4 tiles identical; tile wording 60% the same.

| | PSY-012 (new, Psychiatry) | bank-ext-097 (timed, Psychiatry) |
|---|---|---|
| Title | SSRIs inhibiting serotonin reuptake | Selective serotonin reuptake inhibitors (SSRIs) |
| Tile 1 | Citalopram | Fluoxetine |
| Tile 2 | Escitalopram | Sertraline |
| Tile 3 | Sertraline | Citalopram |
| Tile 4 | Fluoxetine | Paroxetine |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PSY-012 | bank-ext-097": "same" (exclude timed entry at activation) or "distinct"

### Benzodiazepines with oxidative phase I metabolism  /  Benzodiazepines
possible repeat of a timed entry. Shared relationship: "benzodiazepine oxidative phase i metabolism" vs "benzodiazepine"; 3 of 4 tiles identical; tile wording 60% the same.

| | PSY-015 (new, Psychiatry) | bank-ext-099 (timed, Psychiatry) |
|---|---|---|
| Title | Benzodiazepines with oxidative phase I metabolism | Benzodiazepines |
| Tile 1 | Alprazolam | Diazepam |
| Tile 2 | Midazolam | Lorazepam |
| Tile 3 | Diazepam | Alprazolam |
| Tile 4 | Chlordiazepoxide | Midazolam |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PSY-015 | bank-ext-099": "same" (exclude timed entry at activation) or "distinct"

### Antipsychotic-associated extrapyramidal movement disorders  /  Extrapyramidal symptoms of antipsychotics
possible repeat of a timed entry. Shared relationship: "findings / associations of antipsychotic extrapyramidal movement disorder" vs "extrapyramidal symptom antipsychotic"; 4 of 4 tiles identical; tile wording 100% the same.

| | PSY-019 (new, Psychiatry) | bank-ext-100 (timed, Psychiatry) |
|---|---|---|
| Title | Antipsychotic-associated extrapyramidal movement disorders | Extrapyramidal symptoms of antipsychotics |
| Tile 1 | Acute dystonia | Acute dystonia |
| Tile 2 | Drug-induced parkinsonism | Akathisia |
| Tile 3 | Akathisia | Drug-induced parkinsonism |
| Tile 4 | Tardive dyskinesia | Tardive dyskinesia |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PSY-019 | bank-ext-100": "same" (exclude timed entry at activation) or "distinct"

### Lithium-associated adverse effects  /  Adverse effects of lithium
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: both are "findings / associations of lithium adverse effect"; 3 of 4 tiles identical; tile wording 88% the same.

| | PSY-021 (new, Psychiatry) | bank-ext-063 (timed, Psychiatry) |
|---|---|---|
| Title | Lithium-associated adverse effects | Adverse effects of lithium |
| Tile 1 | Nephrogenic diabetes insipidus | Nephrogenic diabetes insipidus |
| Tile 2 | Hypothyroidism | Hypothyroidism |
| Tile 3 | Tremor | Fine tremor |
| Tile 4 | Ebstein anomaly | Ebstein anomaly |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Classic neuroleptic malignant syndrome findings  /  Features of neuroleptic malignant syndrome
possible repeat of a timed entry. Shared relationship: both are "findings / associations of neuroleptic malignant syndrome"; 2 of 4 tiles identical.

| | PSY-023 (new, Psychiatry) | bank-ext-030 (timed, Psychiatry) |
|---|---|---|
| Title | Classic neuroleptic malignant syndrome findings | Features of neuroleptic malignant syndrome |
| Tile 1 | Fever | Hyperthermia |
| Tile 2 | Lead-pipe rigidity | Lead-pipe rigidity |
| Tile 3 | Altered mental status | Autonomic instability |
| Tile 4 | Autonomic instability | Elevated creatine kinase |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PSY-023 | bank-ext-030": "same" (exclude timed entry at activation) or "distinct"

### Neural crest derivatives  /  Neural crest derivatives
possible repeat of a timed entry. Shared relationship: both are "neural crest derivative"; 1 of 4 tiles identical.

| | REPRO-002 (new, Reproductive) | bank-medium-06 (timed, Biochemistry/Genetics) |
|---|---|---|
| Title | Neural crest derivatives | Neural crest derivatives |
| Tile 1 | Melanocytes | Melanocytes |
| Tile 2 | Adrenal medullary chromaffin cells | Schwann cells |
| Tile 3 | Peripheral neurons | Adrenal medulla |
| Tile 4 | Leptomeninges | Peripheral autonomic ganglia |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "REPRO-002 | bank-medium-06": "same" (exclude timed entry at activation) or "distinct"

### Second pharyngeal arch derivatives  /  Pharyngeal arch derivatives
possible repeat of a timed entry. Shared relationship: "second pharyngeal arch derivative" vs "pharyngeal arch derivative"; 1 of 4 tiles identical.

| | REPRO-003 (new, Reproductive) | bank-migrated-sys-mixed-0003-L2 (timed, Mixed / Step Review) |
|---|---|---|
| Title | Second pharyngeal arch derivatives | Pharyngeal arch derivatives |
| Tile 1 | Stapedius muscle | Mandible |
| Tile 2 | Stylohyoid muscle | Stapes |
| Tile 3 | Stapes | Greater horn of hyoid |
| Tile 4 | Lesser horn of hyoid | Thyroid cartilage |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "REPRO-003 | bank-migrated-sys-mixed-0003-L2": "same" (exclude timed entry at activation) or "distinct"

### Ovarian germ cell tumors  /  Ovarian germ cell tumors
possible repeat of a timed entry. Shared relationship: both are "ovarian germ cell tumor"; 2 of 4 tiles identical; tile wording 67% the same.

| | REPRO-017 (new, Reproductive) | bank-ext-094 (timed, Reproductive) |
|---|---|---|
| Title | Ovarian germ cell tumors | Ovarian germ cell tumors |
| Tile 1 | Mature cystic teratoma | Dysgerminoma |
| Tile 2 | Immature teratoma | Yolk sac tumor |
| Tile 3 | Dysgerminoma | Choriocarcinoma |
| Tile 4 | Yolk sac tumor | Mature teratoma |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "REPRO-017 | bank-ext-094": "same" (exclude timed entry at activation) or "distinct"

### Drugs associated with pulmonary fibrosis  /  Drugs causing pulmonary fibrosis
same relationship as a timed entry (timed entry to be excluded at activation). Shared relationship: "findings / associations of drug pulmonary fibrosis" vs "causes of drug causing pulmonary fibrosis"; 4 of 4 tiles identical; tile wording 100% the same.

| | PULM-001 (new, Pulmonary) | bank-ext-062 (timed, Pharmacology) |
|---|---|---|
| Title | Drugs associated with pulmonary fibrosis | Drugs causing pulmonary fibrosis |
| Tile 1 | Bleomycin | Bleomycin |
| Tile 2 | Amiodarone | Amiodarone |
| Tile 3 | Methotrexate | Methotrexate |
| Tile 4 | Busulfan | Busulfan |
| Status | AI_REVIEWED_PASS | verified |

Decide: no decision needed unless you disagree

### Core obstructive lung diseases in the source  /  Obstructive lung diseases
possible repeat of a timed entry. Shared relationship: "core obstructive lung disease" vs "obstructive lung disease"; 2 of 4 tiles identical.

| | PULM-013 (new, Pulmonary) | bank-easy-12 (timed, Pulmonary) |
|---|---|---|
| Title | Core obstructive lung diseases in the source | Obstructive lung diseases |
| Tile 1 | Emphysema | Asthma |
| Tile 2 | Chronic bronchitis | COPD |
| Tile 3 | Asthma | Bronchiectasis |
| Tile 4 | Cystic fibrosis | Cystic fibrosis |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PULM-013 | bank-easy-12": "same" (exclude timed entry at activation) or "distinct"

### Core obstructive lung diseases in the source  /  Obstructive lung diseases
possible repeat of a timed entry. Shared relationship: "core obstructive lung disease" vs "obstructive lung disease"; 2 of 4 tiles identical.

| | PULM-013 (new, Pulmonary) | bank-migrated-sys-pulm-0001-L1 (timed, Pulmonary) |
|---|---|---|
| Title | Core obstructive lung diseases in the source | Obstructive lung diseases |
| Tile 1 | Emphysema | COPD |
| Tile 2 | Chronic bronchitis | Asthma |
| Tile 3 | Asthma | Bronchiectasis |
| Tile 4 | Cystic fibrosis | Cystic fibrosis |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PULM-013 | bank-migrated-sys-pulm-0001-L1": "same" (exclude timed entry at activation) or "distinct"

### Clues to tension pneumothorax  /  Findings in tension pneumothorax
possible repeat of a timed entry. Shared relationship: both are "findings / associations of tension pneumothorax".

| | PULM-020 (new, Pulmonary) | bank-ext-053 (timed, Pulmonary) |
|---|---|---|
| Title | Clues to tension pneumothorax | Findings in tension pneumothorax |
| Tile 1 | Unilateral hyperresonance | Tracheal deviation away from the side |
| Tile 2 | Markedly reduced ipsilateral breath sounds | Absent breath sounds |
| Tile 3 | Contralateral tracheal shift | Hyperresonance to percussion |
| Tile 4 | Hypotension with elevated JVP | Hypotension |
| Status | AI_REVIEWED_PASS | verified |

Decide: decisions.json → pairs → "PULM-020 | bank-ext-053": "same" (exclude timed entry at activation) or "distinct"

## 4. Board ambiguity reviews
### biochemistry-genetics-starter-5 (Biochemistry/Genetics)
- PLX-BCH-050 Classic alkaptonuria associations [easy]: Ochronosis · Black urine after standing · Elevated homogentisate · Arthritis
- PLX-BCH-044 Extrahepatic tissues that can oxidize ketone bodies [medium]: Heart · Brain · Skeletal muscle · Renal cortex
- PLX-BCH-070 Processes supported by peroxisomes [medium]: Very-long-chain fatty acid beta-oxidation · Branched-chain fatty acid alpha-oxidation · Hydrogen peroxide detoxification · Plasmalogen synthesis
- PLX-BCH-077 Aromatic L-amino acid decarboxylase deficiency clues [hard]: Oculogyric crises · Hypotonia · Autonomic dysfunction · Developmental delay
- Flag: PLX-BCH-077 board instruction to check against the other groups: "Avoid a competing neurotransmitter-deficiency category on the same board."
- Clear: decisions.json → boards → "biochemistry-genetics-starter-5": "cleared:4b155f2b"

### gi-starter-3 (GI)
- GI-022 Wilson disease diagnostic associations [easy]: ATP7B mutation · Low ceruloplasmin · Increased urinary copper · Kayser-Fleischer rings
- GI-035 Clinical findings of obstructive cholestasis [easy]: Jaundice · Dark urine · Pale stools · Pruritus
- GI-038 Primary biliary cholangitis clues [medium]: Antimitochondrial antibodies · Small intrahepatic bile duct destruction · Portal-tract (florid duct) granulomas · Xanthelasma
- GI-027 Markers of impaired synthetic/metabolic function in advanced cirrhosis [medium]: Prolonged PT/INR · Low albumin · Hypoglycemia · Hyperammonemia
- Flag: "Pruritus" and "Jaundice" (obstructive cholestasis group) are also classic presenting clues of primary biliary cholangitis, which is on the same board; a player could reasonably place them in the PBC group. (raised by Claude, 2026-10-08)
- Clear: decisions.json → boards → "gi-starter-3": "cleared:3deee08a"

### msk-starter-5 (MSK)
- MSK-015 Dermatomyositis skin findings [easy]: Heliotrope rash · Gottron papules · Shawl sign · V-sign rash
- MSK-007 Clinical consequences of osteopetrosis [medium]: Recurrent fractures · Cranial nerve compression · Pancytopenia · Extramedullary hematopoiesis
- MSK-018 Sarcoidosis diagnostic associations [medium]: Bilateral hilar lymphadenopathy · Noncaseating granulomas · Elevated serum ACE · Increased BAL CD4:CD8 ratio
- MSK-035 High-risk stress fracture sites [hard]: Tension (superolateral) side of the femoral neck · Anterior tibial cortex · Talus · Proximal fifth metatarsal
- Flag: MSK-035 board instruction to check against the other groups: "Board overlap: navicular and sesamoids are additional high-risk sites - avoid as distractors."
- Clear: decisions.json → boards → "msk-starter-5": "cleared:a7cd3b6c"

### renal-starter-5 (Renal)
- NEPH-027 Stress incontinence triggers [easy]: Coughing · Sneezing · Laughing · Heavy lifting
- NEPH-026 Acetazolamide clinical uses [medium]: Glaucoma · Altitude sickness · Idiopathic intracranial hypertension · Metabolic alkalosis
- NEPH-017 Calcium oxalate stone risk exposures [medium]: Ethylene glycol poisoning · Excess vitamin C intake · Fat malabsorption · Hypocitraturia
- NEPH-013 Alport syndrome clues [medium]: Persistent hematuria · Sensorineural hearing loss · Anterior lenticonus · Basket-weave basement membrane
- Flag: NEPH-027 board instruction to check against the other groups: "Board overlap: any Valsalva-maneuver category (ambiguity 1)."
- Clear: decisions.json → boards → "renal-starter-5": "cleared:e2e15784"

### pharmacology-starter-2 (Pharmacology)
- PHARM-009 Peripheral findings of antimuscarinic (anticholinergic) toxicity [easy]: Mydriasis · Dry skin · Urinary retention · Tachycardia
- PHARM-001 Hepatic phase II conjugation reactions [easy]: Glucuronidation · Acetylation · Sulfation · Methylation
- PHARM-006 Direct muscarinic receptor agonists [easy]: Pilocarpine · Cevimeline · Bethanechol · Methacholine
- PHARM-003 CYP (cytochrome P450) enzyme inhibitors [medium]: Cimetidine · Amiodarone · Clarithromycin · Ritonavir
- Flag: PHARM-009 board instruction to check against the other groups: "BOARD OVERLAP: mydriasis and tachycardia also occur in sympathomimetic toxicity."
- Flag: PHARM-001 board instruction to check against the other groups: "Glutathione and amino-acid conjugation are other valid members; a 5th-member board tile could blur this category."
- Flag: PHARM-006 board instruction to check against the other groups: "Carbachol is another valid member (board note)."
- Clear: decisions.json → boards → "pharmacology-starter-2": "cleared:8392d452"

### pharmacology-starter-3 (Pharmacology)
- PHARM-002 Classic CYP (cytochrome P450) enzyme inducers [easy]: Rifampin · Phenobarbital · Carbamazepine · Phenytoin
- PHARM-008 Peripheral muscarinic findings in organophosphate (cholinergic) poisoning [easy]: Miosis · Lacrimation · Bronchospasm · Diarrhea
- PHARM-005 Gs-coupled receptors [medium]: Beta-1 receptor · Beta-2 receptor · D1 receptor · V2 receptor
- PHARM-013 Nonselective beta blockers without alpha blockade [medium]: Nadolol · Propranolol · Timolol · Sotalol
- Flag: PHARM-002 board instruction to check against the other groups: "BOARD OVERLAP: carbamazepine, phenobarbital, phenytoin also fit an antiseizure-drug category; rifampin does not."
- Flag: PHARM-008 board instruction to check against the other groups: "BOARD OVERLAP: each sign individually appears in other toxidromes."
- Flag: PHARM-005 board instruction to check against the other groups: "BOARD OVERLAP: beta-1/beta-2 also fit an adrenergic-receptor category."
- Flag: PHARM-013 board instruction to check against the other groups: "BOARD OVERLAP: sotalol also fits class III antiarrhythmics; its added K-channel activity does not negate its beta-blockade."
- Clear: decisions.json → boards → "pharmacology-starter-3": "cleared:13fca67e"

### psychiatry-starter-3 (Psychiatry)
- PSY-017 Full mu-opioid agonist analgesics [easy]: Morphine · Fentanyl · Hydromorphone · Methadone
- PSY-007 Classic narcolepsy symptom tetrad [easy]: Excessive daytime sleepiness · Cataplexy · Sleep paralysis · Sleep-related hallucinations
- PSY-025 Non-drug delirium reorientation and sleep measures [easy]: Visible clocks · Visible calendars · Protected sleep time · Familiar visitors
- PSY-022 Serotonin syndrome-associated non-antidepressant drugs [medium]: Linezolid · Tramadol · Meperidine · MDMA
- Flag: "Meperidine" and "Tramadol" (serotonin-syndrome group) are themselves opioids with mu-agonist activity, and "Full mu-opioid agonist analgesics" is on the same board; a player could reasonably place meperidine in the opioid group. (raised by Claude, 2026-10-08)
- Clear: decisions.json → boards → "psychiatry-starter-3": "cleared:4e574bc8"

### psychiatry-starter-5 (Psychiatry)
- PSY-006 Positive symptoms of schizophrenia [easy]: Delusions · Hallucinations · Disorganized speech · Disorganized behavior
- PSY-012 SSRIs inhibiting serotonin reuptake [easy]: Citalopram · Escitalopram · Sertraline · Fluoxetine
- PSY-001 Mature defense mechanisms [easy]: Suppression · Altruism · Sublimation · Humor
- PSY-023 Classic neuroleptic malignant syndrome findings [medium]: Fever · Lead-pipe rigidity · Altered mental status · Autonomic instability
- Flag: PSY-006 board instruction to check against the other groups: "Board overlap: schizoaffective, brief psychotic, schizophreniform, and substance-induced psychosis share these; do not present as diagnostic of schizophrenia."
- Flag: PSY-012 board instruction to check against the other groups: "Board caution: escitalopram is the S-enantiomer of citalopram, so the pair are near-duplicates and could be contested as distinct tiles; keep them on separate boards if possible."
- Flag: PSY-001 board instruction to check against the other groups: "Board caution: anticipation, affiliation, self-assertion are also mature defenses and make strong decoys."
- Flag: PSY-023 board instruction to check against the other groups: "Board overlap: fever, altered mental status, and autonomic instability also occur in serotonin syndrome—lead-pipe rigidity (vs clonus/hyperreflexia) is the differentiating tile."
- Clear: decisions.json → boards → "psychiatry-starter-5": "cleared:8478ca7e"

### pulmonary-starter-3 (Pulmonary)
- PULM-012 Alveolar injury triggers of ARDS [easy]: Sepsis · Acute pancreatitis · Pneumonia · Gastric acid aspiration
- PULM-008 Factors shifting the oxygen dissociation curve right [easy]: Acidemia · Increased temperature · Increased carbon dioxide · Increased 2,3-BPG
- PULM-021 Features of diffuse alveolar damage in ARDS [medium]: Protein-rich alveolar fluid · Hyaline membranes · Reduced surfactant activity · Reduced lung compliance
- PULM-010 Hypoxemia mechanisms responsive to supplemental oxygen [medium]: Low inspired oxygen · Alveolar hypoventilation · Diffusion impairment · Ventilation-perfusion mismatch
- Flag: Two ARDS groups on one board ("Alveolar injury triggers of ARDS" and "Features of diffuse alveolar damage in ARDS"). "Pneumonia" and "Sepsis" read as ARDS context next to the DAD features, and "Ventilation-perfusion mismatch" and "Diffusion impairment" (hypoxemia group) are also mechanisms of hypoxemia in ARDS; a player could reasonably mix these groups. (raised by Claude, 2026-10-08)
- Clear: decisions.json → boards → "pulmonary-starter-3": "cleared:1ceae549"

### pulmonary-starter-4 (Pulmonary)
- PULM-002 Paraneoplastic syndromes of small cell lung carcinoma [easy]: SIADH · Ectopic ACTH syndrome · Lambert-Eaton syndrome · Subacute cerebellar degeneration
- PULM-019 Bedside clues to pleural effusion [easy]: Dull percussion · Reduced breath sounds · Reduced tactile fremitus · Contralateral tracheal shift with a large effusion
- PULM-011 Reduced oxygen delivery or use despite normal arterial oxygen tension [medium]: Anemia · Carbon monoxide poisoning · Methemoglobinemia · Cyanide poisoning
- PULM-017 Intrathoracic manifestations of asbestos exposure [medium]: Calcified pleural plaques · Benign asbestos pleural effusion · Pleural mesothelioma · Asbestosis
- Flag: PULM-011 board instruction to check against the other groups: "Board overlap: broader ''causes of tissue hypoxia.'' Added refs: Henretig et al., NEJM 2019;"
- Flag: PULM-017 board instruction to check against the other groups: "BOARD-LEVEL OVERLAP WARNING: three tiles (plaques, benign effusion, mesothelioma) are pleural and could be grouped as ''asbestos pleural disease'' on a 16-tile board; pair with care and avoid a competing pleural category."
- Flag: "Bedside clues to pleural effusion" sits next to the asbestos group, which includes "Benign asbestos pleural effusion"; this is the competing pleural category PULM-017 warns against. (raised by Claude, 2026-10-08)
- Clear: decisions.json → boards → "pulmonary-starter-4": "cleared:3185dfcc"

### reproductive-starter-5 (Reproductive)
- REPRO-004 Structural abnormalities associated with Turner syndrome [easy]: Bicuspid aortic valve · Aortic coarctation · Horseshoe kidney · Cystic hygroma
- REPRO-001 Mesonephric duct derivatives [easy]: Epididymis · Ductus deferens · Seminal vesicle · Ejaculatory duct
- REPRO-007 States associated with elevated beta-hCG [medium]: Multiple gestation · Hydatidiform mole · Choriocarcinoma · Trisomy 21 pregnancy
- REPRO-010 Conditions associated with polyhydramnios [medium]: Anencephaly · Intestinal atresia · Maternal diabetes · Twin-twin transfusion recipient
- Flag: REPRO-007 board instruction to check against the other groups: "Board overlap: mole/choriocarcinoma also fit gestational trophoblastic disease, and trisomy 21 fits quad-screen findings; avoid these competing groups on the same board."
- Flag: REPRO-010 board instruction to check against the other groups: "Only the RECIPIENT twin in TTTS has polyhydramnios; the donor has oligohydramnios (board caution)."
- Clear: decisions.json → boards → "reproductive-starter-5": "cleared:1bf13c51"

## 5. Blocked boards
None.
## 6. Difficulty calibration warnings
Separate from medical and ambiguity issues. These do not block a board.

- PLX-BCH-071 Levels of protein structure [easy] on biochemistry-genetics-starter-1: "Intentionally introductory category; may be too transparent for a Hard puzzle."
- REPRO-015 States of prolonged unopposed estrogen exposure [medium] (Daily pool): "Difficulty raised Easy to Medium."
